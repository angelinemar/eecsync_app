/*import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'announcement_infopage.dart'; // Ensure this path matches your file name

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Announcement Viewer',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        textTheme: GoogleFonts.poppinsTextTheme(),
        useMaterial3: true,
      ),
      home: const AnnouncementInfoPage(
        title: 'Internship ITRI - Recruiting Interns Now',
        publisher: 'eecsoffice@official',
        lastUpdated: '08/03/114',
        descriptionContent: '''
      Hi Students!
      Don’t miss your opportunity to join our Company Visit at ITRI – Hsinchu County on the 36th of March 2090! Meeting points will be shared later via email. Contact us for any questions: thisiscampleasebeaware@gmail.com

      See you!!
      ''',
        // kalau image empty
        //imageUrl: '',
        imageUrl: 'https://www.itri.org.tw/english/WebTools/Thumbnail.ashx?SiteID=1&MmmID=617731531241750114&fd=NewsLetter_Pics&Pname=8E7932E2-B999-41F0-B9AF-456A5831BCD6_%E5%9C%96%E4%B8%80_20250312_00.jpg', // <-- replace with direct image link
      ),
    );
  }
}*/